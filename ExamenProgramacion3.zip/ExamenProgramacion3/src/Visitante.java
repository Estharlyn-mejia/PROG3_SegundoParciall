
import javafx.beans.property.StringProperty;

public class Visitante {
    private StringProperty nombreCompleto;
    private StringProperty tipoVisita;

    public Visitante(StringProperty nombreCompleto, StringProperty tipoVisita) {
        this.nombreCompleto = nombreCompleto;
        this.tipoVisita = tipoVisita;
    }

    public StringProperty getNombreCompleto(){
        return nombreCompleto;
    }

    public StringProperty getTipoVisita(){
        return tipoVisita;
    }
}
