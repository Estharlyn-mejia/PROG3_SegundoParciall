import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;


public class Main extends Application  {

    @Override
    public void start(Stage stage){
        FXMLLoader loader = new FXMLLoader();
        stage.setTitle("Registro visitas");
        loader.setResources(null);
        stage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}