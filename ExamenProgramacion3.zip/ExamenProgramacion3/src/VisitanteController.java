import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class VisitanteController {
    @FXML private TextField txtNombre;

    @FXML private ComboBox<String> cbTipoVisita;
    @FXML private Button btnAgregarVisita;
    @FXML private Button btnGuardarVisitante;
    @FXML private Button btnNuevoTipo;
    @FXML private Button btnEliminar;
    @FXML private Button btnEliminarVisita;


    @FXML private TableView<Visitante> tabla;


    

    private boolean isAcetado = false;
    private Stage stage;

    public boolean isAcetado(){
        isAcetado = true;
        return isAcetado;
    }

    public boolean isCancelado(){
        isAcetado = false;
        return isAcetado;
    }

    public Stage getStage(){
        return stage;
    }

    @FXML
    private void Controller(){
        
    }

    @FXML
    protected void cbTipoVisita(){
        
    }

    

    @FXML
    private void Eliminar(){
        String linea;
        try {
            BufferedReader bw = new BufferedReader(new FileReader("Visitante.txt"));
             while ((linea = bw.readLine()) != null) {
                
             }
        } catch (Exception e) {
           mostrarAlerta("Error al eliminar");
        }
    }

    @FXML
    private void guardar(){
        try {
            FileWriter fw = new FileWriter("RegistroVisita");
            String Linea;

            tabla.getItems().add(p);
                
            
        } catch (Exception e) {
            mostrarAlerta("No se pudo guardar");
        }
    }

    @FXML
    private void agregar(){
        try {
            
            BufferedWriter bw = new BufferedWriter(new FileWriter("RegistroVisitas.txt"));
            String linea;
            for(Visitante datos: visitas){
                Visitante visitas = new Visitante(datos[0], datos[1]);
            }
                
            
        } catch (Exception e) {
            mostrarAlerta("No se pudo agregar a la tabla");
        }
    }

    public void mostrarAlerta(String mensaje){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("INFOM");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
